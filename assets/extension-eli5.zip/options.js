/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!************************!*\
  !*** ./src/options.ts ***!
  \************************/

function getUserInputApiKeyEl() {
    return document.getElementById("apiKey");
}
function getStatusEl() {
    return document.getElementById("status-message");
}
function getSaveButton() {
    return document.getElementById("save-btn");
}
function printMessage(message, success) {
    const status = getStatusEl();
    status.textContent = message;
    status.style.display = "block";
    if (success) {
        status.classList.remove("error");
        status.classList.add("success");
    }
    else {
        status.classList.remove("success");
        status.classList.add("error");
    }
}
function saveOptions() {
    const apiKey = getUserInputApiKeyEl().value;
    if (!apiKey || apiKey.length === 0) {
        printMessage("API Key cannot be empty!", false);
        return;
    }
    chrome.storage.sync.set({
        geminiApiKey: apiKey,
    }, () => {
        printMessage("API Key saved successfully!", true);
        setTimeout(() => {
            printMessage;
            window.close();
        }, 1500);
    });
}
// Function to load the saved API key
function restoreOptions() {
    chrome.storage.sync.get("geminiApiKey", (data) => {
        getUserInputApiKeyEl().value = data.geminiApiKey || "";
    });
}
// Add event listeners
document.addEventListener("DOMContentLoaded", restoreOptions);
getSaveButton().addEventListener("click", saveOptions);
getUserInputApiKeyEl().addEventListener("input", (e) => {
    const value = e.target.value;
    if (!value || value.length === 0) {
        getSaveButton().disabled = true;
    }
    else {
        getSaveButton().disabled = false;
    }
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9ucy5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9lbGk1LWdlbWluaS8uL3NyYy9vcHRpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZ2V0VXNlcklucHV0QXBpS2V5RWwoKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYXBpS2V5XCIpO1xufVxuZnVuY3Rpb24gZ2V0U3RhdHVzRWwoKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic3RhdHVzLW1lc3NhZ2VcIik7XG59XG5mdW5jdGlvbiBnZXRTYXZlQnV0dG9uKCkge1xuICAgIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNhdmUtYnRuXCIpO1xufVxuZnVuY3Rpb24gcHJpbnRNZXNzYWdlKG1lc3NhZ2UsIHN1Y2Nlc3MpIHtcbiAgICBjb25zdCBzdGF0dXMgPSBnZXRTdGF0dXNFbCgpO1xuICAgIHN0YXR1cy50ZXh0Q29udGVudCA9IG1lc3NhZ2U7XG4gICAgc3RhdHVzLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgICAgc3RhdHVzLmNsYXNzTGlzdC5yZW1vdmUoXCJlcnJvclwiKTtcbiAgICAgICAgc3RhdHVzLmNsYXNzTGlzdC5hZGQoXCJzdWNjZXNzXCIpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc3RhdHVzLmNsYXNzTGlzdC5yZW1vdmUoXCJzdWNjZXNzXCIpO1xuICAgICAgICBzdGF0dXMuY2xhc3NMaXN0LmFkZChcImVycm9yXCIpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHNhdmVPcHRpb25zKCkge1xuICAgIGNvbnN0IGFwaUtleSA9IGdldFVzZXJJbnB1dEFwaUtleUVsKCkudmFsdWU7XG4gICAgaWYgKCFhcGlLZXkgfHwgYXBpS2V5Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBwcmludE1lc3NhZ2UoXCJBUEkgS2V5IGNhbm5vdCBiZSBlbXB0eSFcIiwgZmFsc2UpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHtcbiAgICAgICAgZ2VtaW5pQXBpS2V5OiBhcGlLZXksXG4gICAgfSwgKCkgPT4ge1xuICAgICAgICBwcmludE1lc3NhZ2UoXCJBUEkgS2V5IHNhdmVkIHN1Y2Nlc3NmdWxseSFcIiwgdHJ1ZSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgcHJpbnRNZXNzYWdlO1xuICAgICAgICAgICAgd2luZG93LmNsb3NlKCk7XG4gICAgICAgIH0sIDE1MDApO1xuICAgIH0pO1xufVxuLy8gRnVuY3Rpb24gdG8gbG9hZCB0aGUgc2F2ZWQgQVBJIGtleVxuZnVuY3Rpb24gcmVzdG9yZU9wdGlvbnMoKSB7XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJnZW1pbmlBcGlLZXlcIiwgKGRhdGEpID0+IHtcbiAgICAgICAgZ2V0VXNlcklucHV0QXBpS2V5RWwoKS52YWx1ZSA9IGRhdGEuZ2VtaW5pQXBpS2V5IHx8IFwiXCI7XG4gICAgfSk7XG59XG4vLyBBZGQgZXZlbnQgbGlzdGVuZXJzXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCByZXN0b3JlT3B0aW9ucyk7XG5nZXRTYXZlQnV0dG9uKCkuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHNhdmVPcHRpb25zKTtcbmdldFVzZXJJbnB1dEFwaUtleUVsKCkuYWRkRXZlbnRMaXN0ZW5lcihcImlucHV0XCIsIChlKSA9PiB7XG4gICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcbiAgICBpZiAoIXZhbHVlIHx8IHZhbHVlLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBnZXRTYXZlQnV0dG9uKCkuZGlzYWJsZWQgPSB0cnVlO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZ2V0U2F2ZUJ1dHRvbigpLmRpc2FibGVkID0gZmFsc2U7XG4gICAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=